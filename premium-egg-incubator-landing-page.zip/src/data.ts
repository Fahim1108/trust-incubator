export type Plan = {
  id: string;
  name: string;
  bn: string;
  eggs: number;
  price: number;
  oldPrice: number;
  tagline: string;
  forWho: string;
  popular?: boolean;
  features: string[];
};

export const plans: Plan[] = [
  {
    id: "mini",
    name: "Trust Mini",
    bn: "ট্রাস্ট মিনি",
    eggs: 48,
    price: 3990,
    oldPrice: 4990,
    tagline: "Perfect first step",
    forWho: "Students & first-time hatchers",
    features: [
      "48-egg capacity",
      "Automatic egg turning",
      "Digital temperature control",
      "Free Bangla video course",
      "6-month warranty",
    ],
  },
  {
    id: "pro",
    name: "Trust Pro",
    bn: "ট্রাস্ট প্রো",
    eggs: 120,
    price: 7490,
    oldPrice: 9500,
    tagline: "Best for home income",
    forWho: "Housewives & home businesses",
    popular: true,
    features: [
      "120-egg capacity",
      "Auto turning + auto humidity",
      "12V battery backup (handles load-shedding)",
      "Egg candling LED light",
      "Free Bangla course + WhatsApp mentor",
      "1-year warranty",
    ],
  },
  {
    id: "business",
    name: "Trust Business",
    bn: "ট্রাস্ট বিজনেস",
    eggs: 300,
    price: 14900,
    oldPrice: 18500,
    tagline: "Scale into a real farm",
    forWho: "Small farms & entrepreneurs",
    features: [
      "300-egg capacity, dual trays",
      "Smart controller with alarms",
      "Solar + 12V battery ready",
      "Free home setup (Dhaka) & training",
      "Chick buyer network access",
      "2-year warranty",
    ],
  },
];

export const testimonials = [
  {
    name: "Rokeya Begum",
    role: "Housewife · Bogura",
    quote:
      "I started with Trust Pro while my children were at school, then upgraded to Business. Raising 1-month deshi chicks, I now earn around ৳22,000 a month on my own.",
    bn: "এখন আমি নিজেই সংসারের খরচে সাহায্য করতে পারি।",
    stat: "৳22,000/month",
  },
  {
    name: "Tanvir Hasan",
    role: "University student · Rajshahi",
    quote:
      "I bought the Mini with my tuition savings. The Bangla videos made it so easy. My first batch hatched 44 of 48 eggs — I couldn't believe it!",
    bn: "প্রথম ব্যাচেই ৪৮টার মধ্যে ৪৪টা বাচ্চা ফুটেছে!",
    stat: "92% hatch rate",
  },
  {
    name: "Mitu Akter",
    role: "Home entrepreneur · Cumilla",
    quote:
      "Load-shedding was my biggest fear. The battery backup kept everything running through a 6-hour outage. Zero eggs lost. Truly 'Trust'.",
    bn: "৬ ঘণ্টা বিদ্যুৎ ছিল না, একটা ডিমও নষ্ট হয়নি।",
    stat: "0 eggs lost",
  },
  {
    name: "Abdul Karim",
    role: "Job seeker turned farmer · Sylhet",
    quote:
      "After months without a job, I upgraded to Trust Business. Today I supply chicks to 3 local markets and employ my younger brother.",
    bn: "এখন আমি নিজেই অন্যকে কাজ দিচ্ছি।",
    stat: "3 markets supplied",
  },
  {
    name: "Nasrin Sultana",
    role: "Housewife · Khulna",
    quote:
      "The WhatsApp mentor answered every question, even at night. Cash on delivery made me feel safe buying online for the first time.",
    bn: "ক্যাশ অন ডেলিভারি থাকায় নিশ্চিন্তে কিনেছি।",
    stat: "5★ support",
  },
  {
    name: "Shakil Ahmed",
    role: "College student · Barishal",
    quote:
      "Hatching quail and duck eggs alongside chicken. It's become my side business and pays for all my study costs.",
    bn: "পড়াশোনার পুরো খরচ এখন নিজেই চালাই।",
    stat: "3 bird types",
  },
];

export const faqs = [
  {
    q: "I have zero experience. Can I really do this?",
    a: "Absolutely. Over 70% of our customers had never hatched an egg before. Every Trust incubator comes with a step-by-step Bangla video course and a dedicated WhatsApp mentor who guides you from your very first egg to your first chick sale.",
  },
  {
    q: "What happens during load-shedding?",
    a: "Trust Pro and Business models include a 12V battery backup port that switches over automatically when power cuts out — keeping temperature stable for hours. The Business model is also solar-ready for areas with frequent outages.",
  },
  {
    q: "Which eggs can I hatch?",
    a: "Chicken (deshi, sonali, broiler), duck, quail, pigeon, and turkey eggs. Adjustable trays and temperature presets make it easy to switch between bird types.",
  },
  {
    q: "How do I pay? Is Cash on Delivery available?",
    a: "Yes! We offer Cash on Delivery to all 64 districts. You can also pay via bKash, Nagad, Rocket or bank card. EMI options are available on the Pro and Business models.",
  },
  {
    q: "How long does delivery take?",
    a: "Inside Dhaka: 24–48 hours. Outside Dhaka: 2–4 working days. Delivery is free on Pro and Business models across Bangladesh.",
  },
  {
    q: "What if something goes wrong with my incubator?",
    a: "Every unit is covered by our replacement warranty (6 months to 2 years depending on model). We also offer a 7-day easy return if you're not satisfied, plus service centers in Dhaka, Chattogram and Rajshahi.",
  },
  {
    q: "How much can I realistically earn?",
    a: "It depends on your capacity, egg type and local market. Trust Pro owners selling day-old deshi chicks typically earn ৳5,000–৳8,000 per month, while Business owners or those raising chicks to 1 month often earn ৳15,000–৳30,000. Use our earnings calculator above for an estimate based on your setup.",
  },
];
