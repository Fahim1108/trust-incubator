import { useCallback, useEffect, useMemo, useState } from "react";
import { MessageCircle, ArrowRight } from "lucide-react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import Benefits from "./components/Benefits";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import OrderModal from "./components/OrderModal";
import { OrderContext } from "./components/ui";
import { cn } from "./utils/cn";

export default function App() {
  const [modal, setModal] = useState({ open: false, plan: "pro" });
  const [showBar, setShowBar] = useState(false);

  const openOrder = useCallback((plan?: string) => setModal({ open: true, plan: plan ?? "pro" }), []);
  const close = useCallback(() => setModal((m) => ({ ...m, open: false })), []);
  const ctx = useMemo(() => ({ open: openOrder }), [openOrder]);

  useEffect(() => {
    const onScroll = () => setShowBar(window.scrollY > 700);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <OrderContext.Provider value={ctx}>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-lg focus:bg-ink-900 focus:px-4 focus:py-2 focus:text-white"
      >
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <SocialProof />
        <Features />
        <Showcase />
        <Benefits />
        <Testimonials />
        <Pricing />
        <FAQ />
        <CTA />
      </main>
      <Footer />

      {/* Floating WhatsApp */}
      <a
        href="https://wa.me/8801700000000"
        target="_blank"
        rel="noreferrer"
        aria-label="Chat with us on WhatsApp"
        className={cn(
          "fixed right-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-[0_10px_30px_-5px_rgba(37,211,102,0.6)] transition-all duration-500 hover:scale-110 sm:bottom-6 sm:right-6",
          showBar ? "bottom-24" : "bottom-5"
        )}
      >
        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-[#25D366]" />
        <MessageCircle className="relative h-6 w-6" />
      </a>

      {/* Mobile sticky CTA */}
      <div
        className={cn(
          "fixed inset-x-3 bottom-3 z-40 transition-all duration-500 sm:hidden",
          showBar ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-24 opacity-0"
        )}
      >
        <div className="glass flex items-center justify-between gap-3 rounded-2xl p-2.5 pl-4 shadow-[0_10px_40px_-10px_rgba(20,17,13,0.35)]">
          <div>
            <p className="text-[11px] font-medium text-ink-500">Starting from</p>
            <p className="text-lg font-extrabold leading-none">৳3,990</p>
          </div>
          <button
            onClick={() => openOrder()}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-b from-brand-400 to-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-brand-500/40 active:scale-95"
          >
            Order · COD <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <OrderModal open={modal.open} plan={modal.plan} onClose={close} />
    </OrderContext.Provider>
  );
}
