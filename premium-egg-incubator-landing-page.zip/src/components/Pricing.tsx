import { Check, Sparkles, ShieldCheck, Truck, RotateCcw } from "lucide-react";
import { plans } from "@/data";
import { Button, Container, Reveal, SectionHeading, useOrder } from "./ui";
import { cn } from "@/utils/cn";

const fmt = (n: number) => "৳" + n.toLocaleString("en-IN");

export default function Pricing() {
  const { open } = useOrder();
  return (
    <section id="pricing" className="relative scroll-mt-24 py-20 sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-1/3 -z-10 mx-auto h-96 max-w-4xl rounded-full bg-brand-100/70 blur-3xl" />
      <Container>
        <SectionHeading
          eyebrow="Pricing"
          title={
            <>
              Start small. <span className="text-gradient">Grow big.</span>
            </>
          }
          bn="ছোট থেকে শুরু করুন, বড় হয়ে উঠুন"
          subtitle="Honest prices, no hidden fees. Cash on Delivery everywhere in Bangladesh — pay only when your incubator arrives."
        />

        <Reveal delay={200}>
          <div className="mx-auto mt-8 flex w-fit items-center gap-2 rounded-full bg-leaf-50 px-4 py-2 text-sm font-semibold text-leaf-700 ring-1 ring-leaf-100">
            <Sparkles className="h-4 w-4" /> Launch offer: up to 21% off, this month only
          </div>
        </Reveal>

        <div className="mt-12 grid items-stretch gap-5 lg:grid-cols-3">
          {plans.map((p, i) => {
            const save = Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
            return (
              <Reveal key={p.id} delay={i * 110}>
                <article
                  className={cn(
                    "group relative flex h-full flex-col rounded-[2rem] p-7 transition-all duration-500 hover:-translate-y-2 sm:p-8",
                    p.popular
                      ? "bg-ink-900 text-white shadow-[0_40px_80px_-30px_rgba(158,79,10,0.6)] ring-1 ring-brand-500/40 lg:scale-[1.04] lg:hover:scale-[1.04]"
                      : "bg-white ring-1 ring-ink-900/5 hover:shadow-[0_30px_60px_-30px_rgba(20,17,13,0.3)]"
                  )}
                >
                  {p.popular && (
                    <>
                      <div aria-hidden className="absolute inset-0 overflow-hidden rounded-[2rem]">
                        <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-brand-500/30 blur-3xl" />
                        <div className="absolute -bottom-24 -left-16 h-60 w-60 rounded-full bg-leaf-600/25 blur-3xl" />
                      </div>
                      <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-gradient-to-r from-brand-400 to-brand-600 px-4 py-1.5 text-xs font-bold text-white shadow-lg">
                        ⭐ Most popular
                      </span>
                    </>
                  )}

                  <div className="relative">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-bold">{p.name}</h3>
                        <p className={cn("font-bn text-sm", p.popular ? "text-brand-200" : "text-brand-600")}>{p.bn}</p>
                      </div>
                      <span
                        className={cn(
                          "rounded-full px-2.5 py-1 text-xs font-bold",
                          p.popular ? "bg-leaf-500/20 text-leaf-100" : "bg-leaf-50 text-leaf-700"
                        )}
                      >
                        Save {save}%
                      </span>
                    </div>
                    <p className={cn("mt-4 text-sm", p.popular ? "text-white/60" : "text-ink-500")}>{p.forWho}</p>

                    <div className="mt-6 flex items-end gap-2">
                      <span className="text-5xl font-extrabold tracking-tight">{fmt(p.price)}</span>
                      <span className={cn("mb-1.5 text-base line-through", p.popular ? "text-white/40" : "text-ink-500/60")}>{fmt(p.oldPrice)}</span>
                    </div>
                    <p className={cn("mt-1 text-xs", p.popular ? "text-white/50" : "text-ink-500")}>
                      {p.id === "mini" ? "One-time payment" : `or EMI from ${fmt(Math.round(p.price / 6))}/month`}
                    </p>

                    <div className={cn("my-7 h-px", p.popular ? "bg-white/10" : "bg-ink-900/5")} />

                    <ul className="space-y-3.5">
                      {p.features.map((f) => (
                        <li key={f} className="flex items-start gap-3 text-[15px]">
                          <span
                            className={cn(
                              "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full",
                              p.popular ? "bg-brand-500 text-white" : "bg-brand-50 text-brand-600"
                            )}
                          >
                            <Check className="h-3 w-3" strokeWidth={3} />
                          </span>
                          <span className={p.popular ? "text-white/85" : "text-ink-700"}>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="relative mt-auto pt-8">
                    <Button variant={p.popular ? "primary" : "dark"} className="w-full py-4" onClick={() => open(p.id)}>
                      Order {p.name}
                    </Button>
                    <p className={cn("mt-3 text-center text-xs", p.popular ? "text-white/50" : "text-ink-500")}>
                      {p.id === "mini" ? "Delivery ৳120 · COD available" : "Free delivery · COD available"}
                    </p>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={150}>
          <div className="mx-auto mt-14 grid max-w-4xl gap-4 sm:grid-cols-3">
            {[
              { icon: Truck, t: "Cash on Delivery", s: "All 64 districts" },
              { icon: RotateCcw, t: "7-day easy return", s: "No questions asked" },
              { icon: ShieldCheck, t: "Replacement warranty", s: "Up to 2 years" },
            ].map(({ icon: Icon, t, s }) => (
              <div key={t} className="flex items-center gap-3 rounded-2xl bg-white/70 p-4 ring-1 ring-ink-900/5 backdrop-blur">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-leaf-50 text-leaf-600">
                  <Icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-sm font-bold">{t}</p>
                  <p className="text-xs text-ink-500">{s}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-xs font-semibold text-ink-500">
            <span>We accept:</span>
            {["bKash", "Nagad", "Rocket", "Visa", "Mastercard", "Cash"].map((m) => (
              <span key={m} className="rounded-md bg-white px-2.5 py-1 ring-1 ring-ink-900/10">
                {m}
              </span>
            ))}
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
