import { RotateCw, Droplets, BatteryCharging, Thermometer, Lightbulb, GraduationCap } from "lucide-react";
import { Container, Reveal, SectionHeading } from "./ui";
import { cn } from "@/utils/cn";

const features = [
  {
    icon: BatteryCharging,
    title: "Load-shedding? No problem.",
    bn: "বিদ্যুৎ চলে গেলেও চিন্তা নেই",
    desc: "Automatic 12V battery switchover keeps your eggs warm for hours during power cuts. Solar-ready on Business models.",
    span: "lg:col-span-2",
    accent: true,
  },
  {
    icon: RotateCw,
    title: "Auto egg turning",
    bn: "স্বয়ংক্রিয় ডিম ঘোরানো",
    desc: "Turns every 2 hours, day and night — just like a mother hen. No alarms, no manual work.",
  },
  {
    icon: Thermometer,
    title: "±0.1°C precision",
    bn: "নিখুঁত তাপমাত্রা",
    desc: "Smart sensor holds the perfect 37.5°C for healthy, strong chicks every batch.",
  },
  {
    icon: Droplets,
    title: "Smart humidity",
    bn: "আর্দ্রতা নিয়ন্ত্রণ",
    desc: "Built-in humidity control with a simple water channel. The display tells you when to refill.",
  },
  {
    icon: Lightbulb,
    title: "Built-in LED candler",
    bn: "ডিম পরীক্ষার আলো",
    desc: "Check egg fertility in seconds without removing a single egg from the tray.",
  },
  {
    icon: GraduationCap,
    title: "Free Bangla training & mentor",
    bn: "ফ্রি বাংলা ট্রেনিং ও মেন্টর",
    desc: "Step-by-step video course plus a personal WhatsApp mentor who helps you hatch, raise and sell — from day one.",
    span: "lg:col-span-2",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative scroll-mt-24 py-20 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Features"
          title={
            <>
              Engineered for <span className="text-gradient">Bangladeshi homes</span>
            </>
          }
          bn="বাংলাদেশের ঘরের জন্য বিশেষভাবে তৈরি"
          subtitle="Every detail designed around real challenges — power cuts, small spaces and zero experience. Just place your eggs and press start."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 80} className={f.span}>
              <article
                className={cn(
                  "group relative h-full overflow-hidden rounded-3xl p-7 ring-1 transition-all duration-500 hover:-translate-y-1.5 sm:p-8",
                  f.accent
                    ? "grain bg-gradient-to-br from-ink-900 via-[#2a1f12] to-brand-700 text-white ring-white/10 hover:shadow-[0_30px_60px_-20px_rgba(158,79,10,0.6)]"
                    : "bg-white ring-ink-900/5 hover:shadow-[0_24px_60px_-24px_rgba(20,17,13,0.25)]"
                )}
              >
                <div
                  aria-hidden
                  className={cn(
                    "absolute -right-16 -top-16 h-44 w-44 rounded-full blur-3xl transition-all duration-700 group-hover:scale-125",
                    f.accent ? "bg-brand-400/40" : "bg-brand-100/0 group-hover:bg-brand-100"
                  )}
                />
                <span
                  className={cn(
                    "relative grid h-12 w-12 place-items-center rounded-2xl transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110",
                    f.accent ? "bg-white/10 text-brand-200 ring-1 ring-white/20" : "bg-gradient-to-br from-brand-50 to-brand-100 text-brand-600"
                  )}
                >
                  <f.icon className="h-6 w-6" />
                </span>
                <h3 className="relative mt-6 text-xl font-bold tracking-tight">{f.title}</h3>
                <p className={cn("font-bn relative mt-1 text-sm font-medium", f.accent ? "text-brand-200" : "text-brand-600")}>{f.bn}</p>
                <p className={cn("relative mt-3 text-[15px] leading-relaxed", f.accent ? "text-white/70" : "text-ink-500")}>{f.desc}</p>

                {f.accent && (
                  <div className="relative mt-6 flex items-center gap-3 rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
                    <div className="flex h-8 flex-1 items-center gap-1 rounded-lg bg-white/5 p-1">
                      {Array.from({ length: 10 }).map((_, k) => (
                        <span
                          key={k}
                          className={cn(
                            "h-full flex-1 rounded-sm",
                            k < 8 ? "bg-gradient-to-t from-leaf-500 to-leaf-100" : "bg-white/10",
                            k === 7 && "animate-pulse"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-semibold text-leaf-100">Backup: 8 hrs</span>
                  </div>
                )}
              </article>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
