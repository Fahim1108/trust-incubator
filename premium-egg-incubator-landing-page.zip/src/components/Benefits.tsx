import { useMemo, useState } from "react";
import { GraduationCap, Home, Briefcase, TrendingUp, Clock, ArrowRight } from "lucide-react";
import housewifeImg from "@/assets/housewife-chicks.jpg";
import studentImg from "@/assets/student-business.jpg";
import { Button, Container, Reveal, SectionHeading, useOrder } from "./ui";
import { cn } from "@/utils/cn";

const audiences = [
  {
    icon: Home,
    title: "Housewives",
    bn: "গৃহিণীদের জন্য",
    desc: "Earn your own money between household work. Just 15 minutes a day — no need to step outside.",
    points: ["Works from any room", "Flexible daily routine", "Financial independence"],
    img: housewifeImg,
  },
  {
    icon: GraduationCap,
    title: "Students",
    bn: "শিক্ষার্থীদের জন্য",
    desc: "Cover tuition and pocket money with a smart side business that runs while you study.",
    points: ["Low starting cost", "Runs on autopilot", "Real business experience"],
    img: studentImg,
  },
  {
    icon: Briefcase,
    title: "Job seekers",
    bn: "বেকারদের জন্য",
    desc: "Stop waiting for a job — create one. Start small, scale up and build a farm you own.",
    points: ["Income from month one", "Buyer network support", "Scale to a full farm"],
  },
];

const fmt = (n: number) => "৳" + Math.round(n).toLocaleString("en-IN");

function EarningsCalculator() {
  const { open } = useOrder();
  const [eggs, setEggs] = useState(120);
  const [mode, setMode] = useState<"day" | "month">("day");
  const profitPerChick = mode === "day" ? 45 : 95;
  const hatchRate = 0.88;
  const batchesPerMonth = 30 / 22;

  const { chicks, monthly, yearly, investment, payback } = useMemo(() => {
    const chicks = Math.round(eggs * hatchRate * batchesPerMonth);
    const monthly = chicks * profitPerChick;
    const investment = eggs <= 48 ? 3990 : eggs <= 120 ? 7490 : 14900;
    return { chicks, monthly, yearly: monthly * 12, investment, payback: Math.max(1, Math.ceil(investment / (monthly / 30))) };
  }, [eggs, profitPerChick, batchesPerMonth]);

  const pct = ((eggs - 48) / (300 - 48)) * 100;

  return (
    <div id="earnings" className="scroll-mt-28">
      <Reveal>
        <div className="relative overflow-hidden rounded-[2rem] bg-white p-6 shadow-[0_30px_80px_-40px_rgba(158,79,10,0.4)] ring-1 ring-ink-900/5 sm:p-10">
          <div aria-hidden className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brand-100 blur-3xl" />
          <div className="relative grid gap-10 lg:grid-cols-2">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-leaf-50 px-3 py-1 text-xs font-semibold text-leaf-700 ring-1 ring-leaf-100">
                <TrendingUp className="h-3.5 w-3.5" /> Earnings calculator
              </span>
              <h3 className="mt-4 text-2xl font-extrabold tracking-tight sm:text-3xl">How much could you earn?</h3>
              <p className="font-bn mt-1 text-brand-600">আপনি কত আয় করতে পারবেন?</p>

              <div className="mt-8">
                <div className="flex items-center justify-between">
                  <label htmlFor="eggs" className="text-sm font-semibold text-ink-700">
                    Eggs per batch
                  </label>
                  <span className="rounded-lg bg-brand-50 px-3 py-1 text-sm font-bold text-brand-700 tabular-nums">{eggs} eggs</span>
                </div>
                <input
                  id="eggs"
                  type="range"
                  min={48}
                  max={300}
                  step={12}
                  value={eggs}
                  onChange={(e) => setEggs(+e.target.value)}
                  className="mt-4 w-full"
                  style={{ background: `linear-gradient(to right, var(--color-brand-500) ${pct}%, var(--color-cream-200) ${pct}%)` }}
                />
                <div className="mt-2 flex justify-between text-xs font-medium text-ink-500">
                  <span>48 · Mini</span>
                  <span>120 · Pro</span>
                  <span>300 · Business</span>
                </div>
              </div>

              <fieldset className="mt-8">
                <legend className="text-sm font-semibold text-ink-700">I want to sell</legend>
                <div className="mt-3 grid grid-cols-2 gap-2 rounded-2xl bg-cream-100 p-1.5">
                  {(
                    [
                      ["day", "Day-old chicks", "১ দিনের বাচ্চা"],
                      ["month", "1-month chicks", "১ মাসের বাচ্চা"],
                    ] as const
                  ).map(([k, l, b]) => (
                    <button
                      key={k}
                      type="button"
                      aria-pressed={mode === k}
                      onClick={() => setMode(k)}
                      className={cn(
                        "rounded-xl px-3 py-2.5 text-sm font-semibold transition-all duration-300",
                        mode === k ? "bg-white text-ink-900 shadow-md" : "text-ink-500 hover:text-ink-900"
                      )}
                    >
                      {l}
                      <span className="font-bn block text-xs font-normal text-ink-500">{b}</span>
                    </button>
                  ))}
                </div>
              </fieldset>
              <p className="mt-4 text-xs leading-relaxed text-ink-500">
                Based on {Math.round(hatchRate * 100)}% hatch rate, ~1.4 batches/month and avg. profit of ৳{profitPerChick}/deshi chick.
                Actual results vary by market & care.
              </p>
            </div>

            <div className="flex flex-col justify-between rounded-3xl bg-gradient-to-br from-ink-900 via-[#2a1f12] to-brand-700 p-7 text-white grain relative overflow-hidden">
              <div className="relative">
                <p className="text-sm font-medium text-white/60">Estimated monthly profit</p>
                <p key={monthly} className="mt-1 text-5xl font-extrabold tracking-tight tabular-nums sm:text-6xl animate-[fadeUp_.5s_ease]">
                  {fmt(monthly)}
                </p>
                <p className="font-bn mt-1 text-brand-200">প্রতি মাসে সম্ভাব্য লাভ</p>
              </div>
              <div className="relative mt-8 grid grid-cols-3 gap-3">
                {[
                  { l: "Chicks / month", v: chicks.toLocaleString("en-IN") },
                  { l: "Yearly profit", v: fmt(yearly) },
                  { l: "Payback", v: `${payback} days`, icon: Clock },
                ].map((s) => (
                  <div key={s.l} className="rounded-2xl bg-white/[0.07] p-3 ring-1 ring-white/10">
                    <p className="text-[11px] text-white/55">{s.l}</p>
                    <p className="mt-1 text-sm font-bold tabular-nums sm:text-base">{s.v}</p>
                  </div>
                ))}
              </div>
              <Button
                variant="light"
                className="relative mt-6 w-full"
                onClick={() => open(eggs <= 48 ? "mini" : eggs <= 120 ? "pro" : "business")}
              >
                Start earning from {fmt(investment)} <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </div>
        </div>
      </Reveal>
      <style>{`@keyframes fadeUp{from{opacity:.2;transform:translateY(8px)}to{opacity:1;transform:none}}`}</style>
    </div>
  );
}

export default function Benefits() {
  return (
    <section id="benefits" className="relative scroll-mt-24 py-20 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Who it's for"
          title={
            <>
              Your skills don't matter. <span className="text-gradient">Your dreams do.</span>
            </>
          }
          bn="অভিজ্ঞতা লাগবে না — শুধু ইচ্ছাটাই যথেষ্ট"
          subtitle="Thousands of students, housewives and job seekers have turned a small corner of their home into a steady source of income."
        />

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {audiences.map((a, i) => (
            <Reveal key={a.title} delay={i * 100}>
              <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl bg-white ring-1 ring-ink-900/5 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_30px_60px_-25px_rgba(20,17,13,0.3)]">
                {a.img ? (
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={a.img}
                      alt={`${a.title} using a Trust incubator`}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  </div>
                ) : (
                  <div className="relative grid aspect-[16/10] place-items-center overflow-hidden bg-gradient-to-br from-leaf-600 to-leaf-900">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.18),transparent_50%)]" />
                    <div className="relative text-center text-white">
                      <p className="text-5xl font-extrabold">৳0 → ৳17k</p>
                      <p className="mt-2 text-sm text-white/70">Average Business-owner monthly profit</p>
                    </div>
                  </div>
                )}
                <div className="flex flex-1 flex-col p-6 sm:p-7">
                  <div className="flex items-center gap-3">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-600 transition-transform duration-500 group-hover:rotate-6">
                      <a.icon className="h-5 w-5" />
                    </span>
                    <div>
                      <h3 className="text-lg font-bold">{a.title}</h3>
                      <p className="font-bn text-sm text-brand-600">{a.bn}</p>
                    </div>
                  </div>
                  <p className="mt-4 text-[15px] leading-relaxed text-ink-500">{a.desc}</p>
                  <ul className="mt-5 space-y-2">
                    {a.points.map((p) => (
                      <li key={p} className="flex items-center gap-2 text-sm font-medium text-ink-700">
                        <span className="grid h-5 w-5 place-items-center rounded-full bg-leaf-50 text-leaf-600">
                          <svg viewBox="0 0 12 12" className="h-3 w-3" aria-hidden>
                            <path d="M2.5 6.5l2.2 2L9.5 3.5" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" />
                          </svg>
                        </span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <div className="mt-16">
          <EarningsCalculator />
        </div>
      </Container>
    </section>
  );
}
