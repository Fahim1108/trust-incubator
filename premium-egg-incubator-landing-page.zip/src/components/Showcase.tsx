import { useEffect, useState } from "react";
import { Egg, Power, Bird, Check } from "lucide-react";
import heroImg from "@/assets/hero-incubator.jpg";
import chicksImg from "@/assets/chicks-hatching.jpg";
import studentImg from "@/assets/student-business.jpg";
import { Container, Reveal, SectionHeading } from "./ui";
import { cn } from "@/utils/cn";

const steps = [
  {
    icon: Egg,
    title: "Place your eggs",
    bn: "ডিম বসান",
    desc: "Lay fertile chicken, duck or quail eggs on the tray. Adjustable slots fit every size.",
    img: heroImg,
    alt: "Eggs placed inside a Trust incubator tray",
  },
  {
    icon: Power,
    title: "Press start & relax",
    bn: "চালু করুন, নিশ্চিন্ত থাকুন",
    desc: "Temperature, humidity and turning run on autopilot for 21 days. Just top up water weekly.",
    img: chicksImg,
    alt: "Freshly hatched yellow chicks next to cracked eggshells",
  },
  {
    icon: Bird,
    title: "Hatch & earn",
    bn: "বাচ্চা ফুটান, আয় করুন",
    desc: "Sell day-old chicks to neighbours, local markets or our buyer network — and start your next batch.",
    img: studentImg,
    alt: "Young Bangladeshi entrepreneur checking his incubator on a rooftop farm",
  },
];

const specs = [
  ["Capacity", "48 / 120 / 300 eggs"],
  ["Power", "220V AC + 12V DC backup"],
  ["Consumption", "≈ 60W (less than a fan)"],
  ["Temperature", "30–40°C, ±0.1°C"],
  ["Turning", "Auto, every 2 hours"],
  ["Body", "Food-grade ABS, easy-clean"],
];

export default function Showcase() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setActive((a) => (a + 1) % steps.length), 5000);
    return () => clearInterval(t);
  }, [paused]);

  return (
    <section id="showcase" className="relative scroll-mt-24 overflow-hidden bg-ink-900 py-20 text-white sm:py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 left-1/4 h-[32rem] w-[32rem] animate-blob rounded-full bg-brand-600/25 blur-3xl" />
        <div className="absolute -bottom-40 right-0 h-[28rem] w-[28rem] animate-blob rounded-full bg-leaf-600/20 blur-3xl [animation-delay:-8s]" />
      </div>

      <Container className="relative">
        <SectionHeading
          dark
          eyebrow="How it works"
          title={
            <>
              From egg to income in <span className="text-brand-300">21 days</span>
            </>
          }
          bn="মাত্র ২১ দিনে ডিম থেকে আয়"
          subtitle="No technical skills, no big space, no big investment. If you can use a mobile phone, you can run a Trust incubator."
        />

        <div
          className="mt-14 grid items-center gap-10 lg:grid-cols-2 lg:gap-16"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          {/* Image stage */}
          <Reveal>
            <div className="relative aspect-[4/3.2] overflow-hidden rounded-[2rem] ring-1 ring-white/10 shadow-2xl">
              {steps.map((s, i) => (
                <img
                  key={s.title}
                  src={s.img}
                  alt={s.alt}
                  loading="lazy"
                  className={cn(
                    "absolute inset-0 h-full w-full object-cover transition-all duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
                    active === i ? "scale-100 opacity-100" : "scale-110 opacity-0"
                  )}
                />
              ))}
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900/70 via-transparent to-transparent" />
              <div className="glass-dark absolute bottom-4 left-4 right-4 flex items-center justify-between rounded-2xl px-4 py-3">
                <span className="text-sm font-semibold">
                  Step {active + 1} · {steps[active].title}
                </span>
                <span className="font-bn text-sm text-brand-200">{steps[active].bn}</span>
              </div>
            </div>
          </Reveal>

          {/* Steps */}
          <div role="tablist" aria-label="How it works steps" className="flex flex-col gap-3">
            {steps.map((s, i) => (
              <Reveal key={s.title} delay={i * 100}>
                <button
                  role="tab"
                  aria-selected={active === i}
                  onClick={() => setActive(i)}
                  className={cn(
                    "group relative w-full overflow-hidden rounded-3xl p-5 text-left transition-all duration-500 sm:p-6",
                    active === i ? "bg-white/[0.08] ring-1 ring-white/15" : "hover:bg-white/[0.04]"
                  )}
                >
                  <div className="flex gap-4">
                    <span
                      className={cn(
                        "grid h-12 w-12 shrink-0 place-items-center rounded-2xl transition-all duration-500",
                        active === i ? "bg-gradient-to-br from-brand-300 to-brand-600 text-white shadow-lg shadow-brand-600/40" : "bg-white/5 text-white/60"
                      )}
                    >
                      <s.icon className="h-6 w-6" />
                    </span>
                    <div>
                      <h3 className={cn("text-lg font-bold transition-colors", active === i ? "text-white" : "text-white/60")}>
                        <span className="mr-2 text-brand-300">0{i + 1}</span>
                        {s.title}
                      </h3>
                      <div
                        className={cn(
                          "grid transition-all duration-500",
                          active === i ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                        )}
                      >
                        <p className="overflow-hidden pt-1.5 text-[15px] leading-relaxed text-white/65">{s.desc}</p>
                      </div>
                    </div>
                  </div>
                  {active === i && (
                    <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-brand-300 to-leaf-500" style={{ animation: paused ? "none" : "progress 5s linear forwards", width: paused ? "100%" : undefined }} />
                  )}
                </button>
              </Reveal>
            ))}

            <Reveal delay={300}>
              <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-3 rounded-3xl bg-white/[0.04] p-6 ring-1 ring-white/10">
                {specs.map(([k, v]) => (
                  <div key={k} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-leaf-500" />
                    <div>
                      <p className="text-xs text-white/50">{k}</p>
                      <p className="text-sm font-semibold">{v}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
      <style>{`@keyframes progress{from{width:0}to{width:100%}}`}</style>
    </section>
  );
}
