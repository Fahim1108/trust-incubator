import { useEffect, useRef, useState } from "react";
import { X, Check, Loader2, PartyPopper, Minus, Plus } from "lucide-react";
import { plans } from "@/data";
import { Button } from "./ui";
import { cn } from "@/utils/cn";

const districts = [
  "Dhaka", "Chattogram", "Rajshahi", "Khulna", "Sylhet", "Barishal", "Rangpur", "Mymensingh", "Bogura", "Cumilla",
  "Gazipur", "Narayanganj", "Jessore", "Dinajpur", "Tangail", "Pabna", "Noakhali", "Feni", "Kushtia", "Faridpur",
  "Sirajganj", "Cox's Bazar", "Other",
];

const fmt = (n: number) => "৳" + n.toLocaleString("en-IN");

export default function OrderModal({ open, plan, onClose }: { open: boolean; plan: string; onClose: () => void }) {
  const [selected, setSelected] = useState(plan);
  const [qty, setQty] = useState(1);
  const [payment, setPayment] = useState<"cod" | "bkash">("cod");
  const [form, setForm] = useState({ name: "", phone: "", district: "Dhaka", address: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [orderId, setOrderId] = useState("");
  const firstInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setSelected(plan);
      setStatus("idle");
      setErrors({});
      document.body.style.overflow = "hidden";
      setTimeout(() => firstInput.current?.focus(), 350);
    } else {
      document.body.style.overflow = "";
    }
  }, [open, plan]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const p = plans.find((x) => x.id === selected) ?? plans[1];
  const delivery = p.id === "mini" ? (form.district === "Dhaka" ? 80 : 120) : 0;
  const total = p.price * qty + delivery;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (form.name.trim().length < 2) errs.name = "Please enter your full name";
    if (!/^(?:\+?88)?01[3-9]\d{8}$/.test(form.phone.replace(/[\s-]/g, ""))) errs.phone = "Enter a valid BD mobile number (01XXXXXXXXX)";
    if (form.address.trim().length < 6) errs.address = "Please enter your delivery address";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setStatus("loading");
    setTimeout(() => {
      setOrderId("TI-" + Math.floor(100000 + Math.random() * 900000));
      setStatus("done");
    }, 1200);
  };

  const field = "w-full rounded-xl bg-cream-50 px-4 py-3 text-[15px] ring-1 ring-ink-900/10 outline-none transition placeholder:text-ink-500/60 focus:bg-white focus:ring-2 focus:ring-brand-400";

  return (
    <div
      className={cn("fixed inset-0 z-[100] flex items-end justify-center sm:items-center sm:p-6", open ? "pointer-events-auto" : "pointer-events-none")}
      aria-hidden={!open}
      inert={!open}
    >
      <div
        onClick={onClose}
        className={cn("absolute inset-0 bg-ink-900/50 backdrop-blur-sm transition-opacity duration-500", open ? "opacity-100" : "opacity-0")}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="order-title"
        className={cn(
          "relative max-h-[94vh] w-full max-w-2xl overflow-y-auto rounded-t-[2rem] bg-white shadow-2xl transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] sm:rounded-[2rem]",
          open ? "translate-y-0 opacity-100 sm:scale-100" : "translate-y-full opacity-0 sm:translate-y-8 sm:scale-95"
        )}
      >
        <button
          onClick={onClose}
          aria-label="Close order form"
          className="absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-cream-100 text-ink-700 transition hover:rotate-90 hover:bg-cream-200"
        >
          <X className="h-5 w-5" />
        </button>

        {status === "done" ? (
          <div className="px-6 py-14 text-center sm:px-12">
            <div className="relative mx-auto grid h-20 w-20 place-items-center rounded-full bg-leaf-50 text-leaf-600">
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-leaf-100" />
              <PartyPopper className="relative h-9 w-9" />
            </div>
            <h2 id="order-title" className="mt-6 text-3xl font-extrabold tracking-tight">Order confirmed! 🎉</h2>
            <p className="font-bn mt-2 text-lg text-brand-600">অভিনন্দন! আপনার অর্ডার গ্রহণ করা হয়েছে।</p>
            <p className="mx-auto mt-4 max-w-md text-ink-500">
              Thank you, {form.name.split(" ")[0]}! Our team will call you at <b className="text-ink-900">{form.phone}</b> within 2 hours to
              confirm delivery of your {p.name}.
            </p>
            <div className="mx-auto mt-6 w-fit rounded-2xl bg-cream-100 px-5 py-3 text-sm">
              Order ID: <b className="tabular-nums">{orderId}</b> · Total: <b>{fmt(total)}</b>
            </div>
            <Button variant="dark" className="mt-8" onClick={onClose}>
              Back to site
            </Button>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="p-6 sm:p-10">
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-ink-900/10 sm:hidden" />
            <h2 id="order-title" className="text-2xl font-extrabold tracking-tight sm:text-3xl">Place your order</h2>
            <p className="font-bn mt-1 text-brand-600">অর্ডার করুন — পণ্য হাতে পেয়ে টাকা দিন</p>

            <fieldset className="mt-6">
              <legend className="mb-3 text-sm font-semibold text-ink-700">Choose your incubator</legend>
              <div className="grid gap-2 sm:grid-cols-3">
                {plans.map((x) => (
                  <label
                    key={x.id}
                    className={cn(
                      "relative cursor-pointer rounded-2xl p-4 ring-1 transition-all duration-300",
                      selected === x.id ? "bg-brand-50 ring-2 ring-brand-500" : "ring-ink-900/10 hover:ring-ink-900/25"
                    )}
                  >
                    <input type="radio" name="plan" value={x.id} checked={selected === x.id} onChange={() => setSelected(x.id)} className="sr-only" />
                    {selected === x.id && (
                      <span className="absolute right-3 top-3 grid h-5 w-5 place-items-center rounded-full bg-brand-500 text-white">
                        <Check className="h-3 w-3" strokeWidth={3} />
                      </span>
                    )}
                    <p className="text-sm font-bold">{x.name}</p>
                    <p className="text-xs text-ink-500">{x.eggs} eggs</p>
                    <p className="mt-2 font-extrabold">{fmt(x.price)}</p>
                  </label>
                ))}
              </div>
            </fieldset>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="o-name" className="mb-1.5 block text-sm font-semibold text-ink-700">Full name / নাম</label>
                <input
                  ref={firstInput}
                  id="o-name"
                  autoComplete="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Rokeya Begum"
                  className={cn(field, errors.name && "ring-2 ring-red-400")}
                  aria-invalid={!!errors.name}
                  aria-describedby={errors.name ? "e-name" : undefined}
                />
                {errors.name && <p id="e-name" className="mt-1 text-xs text-red-600">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="o-phone" className="mb-1.5 block text-sm font-semibold text-ink-700">Mobile / মোবাইল</label>
                <input
                  id="o-phone"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="01XXXXXXXXX"
                  className={cn(field, errors.phone && "ring-2 ring-red-400")}
                  aria-invalid={!!errors.phone}
                  aria-describedby={errors.phone ? "e-phone" : undefined}
                />
                {errors.phone && <p id="e-phone" className="mt-1 text-xs text-red-600">{errors.phone}</p>}
              </div>
              <div>
                <label htmlFor="o-district" className="mb-1.5 block text-sm font-semibold text-ink-700">District / জেলা</label>
                <select
                  id="o-district"
                  value={form.district}
                  onChange={(e) => setForm({ ...form, district: e.target.value })}
                  className={field}
                >
                  {districts.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div>
                <span className="mb-1.5 block text-sm font-semibold text-ink-700">Quantity</span>
                <div className="flex items-center justify-between rounded-xl bg-cream-50 p-1.5 ring-1 ring-ink-900/10">
                  <button type="button" aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-9 w-9 place-items-center rounded-lg bg-white shadow-sm transition active:scale-90">
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="font-bold tabular-nums" aria-live="polite">{qty}</span>
                  <button type="button" aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(10, q + 1))} className="grid h-9 w-9 place-items-center rounded-lg bg-white shadow-sm transition active:scale-90">
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="o-address" className="mb-1.5 block text-sm font-semibold text-ink-700">Full address / ঠিকানা</label>
                <textarea
                  id="o-address"
                  rows={2}
                  autoComplete="street-address"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder="House, road, area, upazila"
                  className={cn(field, "resize-none", errors.address && "ring-2 ring-red-400")}
                  aria-invalid={!!errors.address}
                  aria-describedby={errors.address ? "e-address" : undefined}
                />
                {errors.address && <p id="e-address" className="mt-1 text-xs text-red-600">{errors.address}</p>}
              </div>
            </div>

            <fieldset className="mt-5">
              <legend className="mb-2 text-sm font-semibold text-ink-700">Payment</legend>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    ["cod", "Cash on Delivery", "পণ্য হাতে পেয়ে"],
                    ["bkash", "bKash / Nagad", "অগ্রিম পেমেন্ট"],
                  ] as const
                ).map(([k, l, b]) => (
                  <label
                    key={k}
                    className={cn(
                      "cursor-pointer rounded-xl p-3 text-sm ring-1 transition-all",
                      payment === k ? "bg-leaf-50 ring-2 ring-leaf-500" : "ring-ink-900/10 hover:ring-ink-900/25"
                    )}
                  >
                    <input type="radio" name="pay" className="sr-only" checked={payment === k} onChange={() => setPayment(k)} />
                    <span className="block font-semibold">{l}</span>
                    <span className="font-bn block text-xs text-ink-500">{b}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            <div className="mt-6 rounded-2xl bg-cream-100 p-4 text-sm">
              <div className="flex justify-between text-ink-500">
                <span>{p.name} × {qty}</span>
                <span>{fmt(p.price * qty)}</span>
              </div>
              <div className="mt-1 flex justify-between text-ink-500">
                <span>Delivery</span>
                <span>{delivery ? fmt(delivery) : <b className="text-leaf-600">FREE</b>}</span>
              </div>
              <div className="mt-3 flex justify-between border-t border-ink-900/10 pt-3 text-base font-extrabold">
                <span>Total</span>
                <span className="tabular-nums">{fmt(total)}</span>
              </div>
            </div>

            <Button type="submit" className="mt-6 w-full py-4 text-base" disabled={status === "loading"}>
              {status === "loading" ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" /> Placing order…
                </>
              ) : (
                <>Confirm order · {fmt(total)}</>
              )}
            </Button>
            <p className="mt-3 text-center text-xs text-ink-500">🔒 Your information is safe. We'll call to confirm before shipping.</p>
          </form>
        )}
      </div>
    </div>
  );
}
