import { Quote, Star, BadgeCheck } from "lucide-react";
import housewifeImg from "@/assets/housewife-chicks.jpg";
import { testimonials } from "@/data";
import { Container, Reveal, SectionHeading } from "./ui";

const colors = ["#e8890b", "#0f9f6e", "#c76a06", "#065f46", "#9e4f0a", "#087f5b"];

export default function Testimonials() {
  const [featured, ...rest] = testimonials;
  return (
    <section id="testimonials" className="relative scroll-mt-24 overflow-hidden bg-gradient-to-b from-cream-100 to-cream-50 py-20 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Real stories"
          title={
            <>
              Real people. <span className="text-gradient">Real income.</span>
            </>
          }
          bn="সত্যিকারের মানুষ, সত্যিকারের সাফল্য"
          subtitle="Meet a few of the 12,000+ Bangladeshis who started hatching their future with Trust."
        />

        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {/* Featured */}
          <Reveal className="lg:row-span-2">
            <figure className="group relative flex h-full min-h-[30rem] flex-col justify-end overflow-hidden rounded-[2rem] ring-1 ring-ink-900/5">
              <img
                src={housewifeImg}
                alt="Rokeya Begum holding a baby chick beside her Trust incubator"
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1500ms] group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/50 to-transparent" />
              <div className="relative p-7 text-white sm:p-8">
                <span className="inline-flex rounded-full bg-brand-500 px-3 py-1 text-xs font-bold">{featured.stat}</span>
                <blockquote className="mt-4 text-xl leading-snug font-semibold sm:text-2xl">“{featured.quote}”</blockquote>
                <p className="font-bn mt-3 text-brand-200">{featured.bn}</p>
                <figcaption className="mt-5 flex items-center gap-2 text-sm">
                  <span className="font-bold">{featured.name}</span>
                  <BadgeCheck className="h-4 w-4 text-leaf-500" aria-label="Verified buyer" />
                  <span className="text-white/60">· {featured.role}</span>
                </figcaption>
              </div>
            </figure>
          </Reveal>

          {rest.slice(0, 4).map((t, i) => (
            <Reveal key={t.name} delay={(i % 2) * 100 + 80}>
              <figure className="group relative flex h-full flex-col rounded-3xl bg-white/80 p-6 ring-1 ring-ink-900/5 backdrop-blur transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_24px_50px_-24px_rgba(158,79,10,0.35)] sm:p-7">
                <div className="flex items-center justify-between">
                  <div className="flex text-brand-400" aria-label="5 out of 5 stars">
                    {Array.from({ length: 5 }).map((_, k) => (
                      <Star key={k} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <Quote className="h-7 w-7 text-brand-100 transition-colors duration-500 group-hover:text-brand-200" />
                </div>
                <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-ink-700">“{t.quote}”</blockquote>
                <p className="font-bn mt-3 text-sm font-medium text-brand-600">{t.bn}</p>
                <figcaption className="mt-5 flex items-center justify-between gap-3 border-t border-ink-900/5 pt-5">
                  <div className="flex items-center gap-3">
                    <span
                      className="grid h-10 w-10 place-items-center rounded-full text-sm font-bold text-white"
                      style={{ background: colors[i % colors.length] }}
                      aria-hidden
                    >
                      {t.name
                        .split(" ")
                        .map((w) => w[0])
                        .join("")}
                    </span>
                    <div>
                      <p className="text-sm font-bold">{t.name}</p>
                      <p className="text-xs text-ink-500">{t.role}</p>
                    </div>
                  </div>
                  <span className="whitespace-nowrap rounded-full bg-leaf-50 px-2.5 py-1 text-[11px] font-bold text-leaf-700">{t.stat}</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
