import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { cn } from "@/utils/cn";
import { Button, useOrder } from "./ui";

const links = [
  { href: "#features", label: "Features" },
  { href: "#showcase", label: "Product" },
  { href: "#earnings", label: "Earnings" },
  { href: "#testimonials", label: "Stories" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <a href="#top" className="flex items-center gap-2.5" aria-label="Trust Incubator home">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-300 to-brand-600 shadow-lg shadow-brand-500/30">
        <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
          <path d="M12 2.5c-4 0-7 6-7 10.5a7 7 0 0 0 14 0C19 8.5 16 2.5 12 2.5Z" fill="white" />
          <path d="M8.5 13.5l2.3 2.3 4.7-4.8" stroke="#c76a06" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span className={cn("text-lg font-extrabold tracking-tight", light ? "text-white" : "text-ink-900")}>
        Trust<span className="text-brand-500">.</span>
        <span className={cn("ml-1 font-semibold", light ? "text-white/60" : "text-ink-500")}>Incubator</span>
      </span>
    </a>
  );
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const { open: openOrder } = useOrder();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive("#" + e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" }
    );
    links.forEach((l) => {
      const el = document.querySelector(l.href);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5">
      <nav
        aria-label="Main"
        className={cn(
          "mx-auto flex max-w-7xl items-center justify-between rounded-2xl px-4 py-2.5 transition-all duration-500 sm:px-5",
          scrolled ? "glass shadow-[0_8px_30px_-12px_rgba(20,17,13,0.18)]" : "bg-transparent"
        )}
      >
        <Logo />

        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className={cn(
                  "relative rounded-full px-4 py-2 text-sm font-medium transition-colors",
                  active === l.href ? "text-ink-900" : "text-ink-500 hover:text-ink-900"
                )}
              >
                {active === l.href && <span className="absolute inset-0 -z-10 rounded-full bg-white shadow-sm ring-1 ring-ink-900/5" />}
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href="tel:+8809610000000"
            className="hidden items-center gap-2 rounded-full px-3 py-2 text-sm font-semibold text-ink-700 hover:text-brand-600 md:flex"
          >
            <Phone className="h-4 w-4" /> 09610-000000
          </a>
          <Button onClick={() => openOrder()} className="hidden px-5 py-2.5 sm:inline-flex">
            Order Now
          </Button>
          <button
            onClick={() => setOpen((o) => !o)}
            className="grid h-10 w-10 place-items-center rounded-xl bg-white/80 ring-1 ring-ink-900/10 lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={cn(
          "mx-auto mt-2 max-w-7xl overflow-hidden rounded-2xl transition-all duration-500 lg:hidden",
          open ? "glass max-h-[80vh] opacity-100 shadow-xl" : "max-h-0 opacity-0"
        )}
      >
        <ul className="flex flex-col p-3">
          {links.map((l, i) => (
            <li
              key={l.href}
              style={{ transitionDelay: open ? `${i * 40}ms` : "0ms" }}
              className={cn("transition-all duration-500", open ? "translate-y-0 opacity-100" : "-translate-y-2 opacity-0")}
            >
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-xl px-4 py-3 text-base font-semibold text-ink-700 hover:bg-white"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li className="mt-2 px-1 pb-1">
            <Button
              className="w-full"
              onClick={() => {
                setOpen(false);
                openOrder();
              }}
            >
              Order Now · Cash on Delivery
            </Button>
          </li>
        </ul>
      </div>
    </header>
  );
}
