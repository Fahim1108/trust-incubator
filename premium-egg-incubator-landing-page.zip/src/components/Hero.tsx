import { useEffect, useRef, useState } from "react";
import { ArrowRight, PlayCircle, Truck, ShieldCheck, Wallet, Thermometer, Star } from "lucide-react";
import heroImg from "@/assets/hero-incubator.jpg";
import { Button, Container, useOrder } from "./ui";

export default function Hero() {
  const { open } = useOrder();
  const wrap = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [temp, setTemp] = useState(37.5);
  const [day, setDay] = useState(14);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 60);
    const i = setInterval(() => setTemp(37.4 + Math.round(Math.random() * 2) / 10), 2200);
    const d = setInterval(() => setDay((v) => (v >= 21 ? 14 : v + 1)), 1600);
    return () => {
      clearTimeout(t);
      clearInterval(i);
      clearInterval(d);
    };
  }, []);

  const onMove = (e: React.MouseEvent) => {
    const r = wrap.current?.getBoundingClientRect();
    if (!r) return;
    setTilt({ x: ((e.clientX - r.left) / r.width - 0.5) * 2, y: ((e.clientY - r.top) / r.height - 0.5) * 2 });
  };

  const delays = ["delay-0", "delay-100", "delay-200", "delay-300", "delay-500", "delay-700"];
  const enter = (i: number) =>
    `transition-all duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)] ${delays[i]} ${loaded ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-6 blur-sm"}`;

  return (
    <section id="top" className="relative overflow-hidden pt-28 pb-16 sm:pt-36 lg:pb-28">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,var(--color-cream-200),transparent_60%)]" />
        <div className="absolute -top-24 -left-24 h-[28rem] w-[28rem] animate-blob rounded-full bg-brand-200/60 blur-3xl" />
        <div className="absolute top-40 -right-32 h-[30rem] w-[30rem] animate-blob rounded-full bg-leaf-100/70 blur-3xl [animation-delay:-6s]" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 animate-blob rounded-full bg-brand-100 blur-3xl [animation-delay:-12s]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(20,17,13,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(20,17,13,0.04)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
      </div>

      <Container className="grid items-center gap-14 lg:grid-cols-[1.05fr_1fr] lg:gap-10">
        {/* Copy */}
        <div className="text-center lg:text-left">
          <div className={enter(0)}>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/80 py-1.5 pr-4 pl-1.5 text-xs font-semibold text-ink-700 shadow-sm ring-1 ring-ink-900/5 backdrop-blur sm:text-sm">
              <span className="rounded-full bg-leaf-600 px-2.5 py-0.5 text-[11px] font-bold text-white">NEW</span>
              Load-shedding proof · Battery backup built in
            </span>
          </div>

          <h1 className={`mt-6 text-[2.6rem] leading-[1.03] font-extrabold tracking-tight text-balance sm:text-6xl lg:text-[4.4rem] ${enter(1)}`}>
            Hatch chicks at home.
            <br />
            <span className="text-gradient">Hatch your income.</span>
          </h1>

          <p className={`font-bn mt-5 text-xl font-semibold text-brand-700 sm:text-2xl ${enter(2)}`}>
            ঘরে বসেই আয় শুরু করুন — মাত্র ৳৩,৯৯০ থেকে
          </p>

          <p className={`mx-auto mt-4 max-w-xl text-base leading-relaxed text-ink-500 sm:text-lg lg:mx-0 ${enter(3)}`}>
            Trust Incubator gives students, housewives and job seekers across Bangladesh a smart, fully automatic
            egg incubator — plus free Bangla training — to build a reliable income without leaving home.
          </p>

          <div className={`mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start ${enter(4)}`}>
            <Button onClick={() => open("pro")} className="w-full px-7 py-4 text-base sm:w-auto">
              Order Now — Cash on Delivery
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Button>
            <a
              href="#showcase"
              className="group inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-4 text-base font-semibold text-ink-700 transition hover:text-ink-900 sm:w-auto"
            >
              <PlayCircle className="h-5 w-5 text-brand-500 transition-transform group-hover:scale-110" />
              See how it works
            </a>
          </div>

          <ul className={`mt-9 grid grid-cols-3 gap-3 text-left sm:max-w-lg lg:max-w-none ${enter(5)} mx-auto lg:mx-0`}>
            {[
              { icon: Truck, t: "64 districts", s: "Fast delivery" },
              { icon: Wallet, t: "COD / bKash", s: "Pay your way" },
              { icon: ShieldCheck, t: "Up to 2 yrs", s: "Warranty" },
            ].map(({ icon: Icon, t, s }) => (
              <li key={t} className="flex flex-col items-center gap-2 rounded-2xl bg-white/60 p-3 text-center ring-1 ring-ink-900/5 backdrop-blur sm:flex-row sm:text-left">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600">
                  <Icon className="h-[18px] w-[18px]" />
                </span>
                <span>
                  <span className="block text-[13px] font-bold text-ink-900">{t}</span>
                  <span className="block text-xs text-ink-500">{s}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Visual */}
        <div
          ref={wrap}
          onMouseMove={onMove}
          onMouseLeave={() => setTilt({ x: 0, y: 0 })}
          className={`relative mx-auto w-full max-w-xl [perspective:1200px] ${enter(2)}`}
        >
          <div
            className="relative transition-transform duration-500 ease-out"
            style={{ transform: `rotateY(${tilt.x * 5}deg) rotateX(${-tilt.y * 5}deg)` }}
          >
            <div className="absolute inset-6 -z-10 rounded-[2.5rem] bg-gradient-to-br from-brand-300/60 to-leaf-500/30 blur-2xl" />
            <div className="animate-float overflow-hidden rounded-[2rem] bg-cream-100 shadow-[0_40px_80px_-30px_rgba(158,79,10,0.45)] ring-1 ring-white">
              <img
                src={heroImg}
                alt="Trust Pro automatic egg incubator with clear dome and warm-lit eggs, showing 37.5°C on its digital display"
                className="aspect-[4/3.4] w-full object-cover"
                fetchPriority="high"
              />
            </div>

            {/* Floating cards */}
            <div
              className="glass absolute -left-3 top-8 rounded-2xl p-3.5 shadow-xl sm:-left-8"
              style={{ transform: `translate(${tilt.x * -12}px, ${tilt.y * -12}px)` }}
            >
              <div className="flex items-center gap-3">
                <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-brand-500 text-white">
                  <span className="absolute inset-0 animate-pulse-ring rounded-xl bg-brand-400" />
                  <Thermometer className="relative h-5 w-5" />
                </span>
                <div>
                  <p className="text-[11px] font-medium text-ink-500">Live temperature</p>
                  <p className="text-lg font-extrabold tabular-nums">{temp.toFixed(1)}°C</p>
                </div>
              </div>
            </div>

            <div
              className="glass absolute -right-2 bottom-24 w-44 rounded-2xl p-4 shadow-xl sm:-right-8"
              style={{ transform: `translate(${tilt.x * 14}px, ${tilt.y * 14}px)` }}
            >
              <div className="flex items-center justify-between text-[11px] font-medium text-ink-500">
                <span>Hatching progress</span>
                <span className="font-bold text-leaf-600">Day {day}</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink-900/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-400 to-leaf-500 transition-all duration-700"
                  style={{ width: `${(day / 21) * 100}%` }}
                />
              </div>
              <p className="mt-2 text-xs font-semibold text-ink-700">{21 - day === 0 ? "🐣 Chicks are hatching!" : `${21 - day} days to hatch`}</p>
            </div>

            <div
              className="glass absolute -bottom-6 left-6 flex items-center gap-3 rounded-2xl px-4 py-3 shadow-xl sm:left-12"
              style={{ transform: `translate(${tilt.x * -8}px, ${tilt.y * 8}px)` }}
            >
              <div className="flex -space-x-2">
                {["RB", "TH", "MA", "AK"].map((n, i) => (
                  <span
                    key={n}
                    className="grid h-8 w-8 place-items-center rounded-full text-[10px] font-bold text-white ring-2 ring-white"
                    style={{ background: ["#e8890b", "#0f9f6e", "#c76a06", "#065f46"][i] }}
                  >
                    {n}
                  </span>
                ))}
              </div>
              <div>
                <div className="flex text-brand-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-3.5 w-3.5 fill-current" />
                  ))}
                </div>
                <p className="text-xs font-semibold text-ink-700">12,000+ happy hatchers</p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
