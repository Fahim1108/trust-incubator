import { useState } from "react";
import { Plus, MessageCircle } from "lucide-react";
import { faqs } from "@/data";
import { Container, Reveal, SectionHeading } from "./ui";
import { cn } from "@/utils/cn";

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative scroll-mt-24 py-20 sm:py-28">
      <Container className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <SectionHeading
            center={false}
            eyebrow="FAQ"
            title="Questions? We've got answers."
            bn="আপনার প্রশ্নের উত্তর এখানে"
            subtitle="Can't find what you're looking for? Our Bangla-speaking team is available 9am–10pm, every day."
          />
          <Reveal delay={250}>
            <a
              href="https://wa.me/8801700000000"
              target="_blank"
              rel="noreferrer"
              className="group mt-8 inline-flex items-center gap-3 rounded-2xl bg-white p-4 pr-6 ring-1 ring-ink-900/5 transition-all hover:-translate-y-0.5 hover:shadow-lg"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#25D366] text-white">
                <MessageCircle className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-sm font-bold">Chat on WhatsApp</span>
                <span className="font-bn block text-xs text-ink-500">বাংলায় কথা বলুন</span>
              </span>
            </a>
          </Reveal>
        </div>

        <div className="space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={f.q} delay={i * 60}>
                <div
                  className={cn(
                    "rounded-2xl ring-1 transition-all duration-500",
                    isOpen ? "bg-white shadow-[0_20px_50px_-30px_rgba(158,79,10,0.4)] ring-brand-100" : "bg-white/50 ring-ink-900/5 hover:bg-white"
                  )}
                >
                  <h3>
                    <button
                      id={`faq-btn-${i}`}
                      aria-expanded={isOpen}
                      aria-controls={`faq-panel-${i}`}
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="flex w-full items-center justify-between gap-4 rounded-2xl p-5 text-left text-base font-semibold focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-brand-200 sm:p-6 sm:text-lg"
                    >
                      {f.q}
                      <span
                        className={cn(
                          "grid h-8 w-8 shrink-0 place-items-center rounded-full transition-all duration-500",
                          isOpen ? "rotate-45 bg-brand-500 text-white" : "bg-cream-100 text-ink-700"
                        )}
                      >
                        <Plus className="h-4 w-4" />
                      </span>
                    </button>
                  </h3>
                  <div
                    id={`faq-panel-${i}`}
                    role="region"
                    aria-labelledby={`faq-btn-${i}`}
                    className={cn("grid transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]", isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-6 text-[15px] leading-relaxed text-ink-500 sm:px-6">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
