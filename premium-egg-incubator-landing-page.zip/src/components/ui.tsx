import { createContext, useContext, useEffect, useRef, useState, type ElementType, type ReactNode } from "react";
import { cn } from "@/utils/cn";

/* ---------- Reveal on scroll ---------- */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: ElementType;
}) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      ref={ref}
      className={cn("reveal", visible && "is-visible", className)}
      style={{ "--d": `${delay}ms` } as React.CSSProperties}
    >
      {children}
    </Tag>
  );
}

/* ---------- Section heading ---------- */
export function SectionHeading({
  eyebrow,
  title,
  bn,
  subtitle,
  center = true,
  dark = false,
}: {
  eyebrow: string;
  title: ReactNode;
  bn?: string;
  subtitle?: string;
  center?: boolean;
  dark?: boolean;
}) {
  return (
    <div className={cn("max-w-2xl", center && "mx-auto text-center")}>
      <Reveal>
        <span
          className={cn(
            "inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.16em]",
            dark ? "bg-white/10 text-brand-200 ring-1 ring-white/15" : "bg-brand-50 text-brand-700 ring-1 ring-brand-100"
          )}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={80}>
        <h2
          className={cn(
            "mt-5 text-3xl font-extrabold leading-[1.1] tracking-tight text-balance sm:text-4xl lg:text-[2.85rem]",
            dark ? "text-white" : "text-ink-900"
          )}
        >
          {title}
        </h2>
      </Reveal>
      {bn && (
        <Reveal delay={140}>
          <p className={cn("font-bn mt-3 text-lg font-medium", dark ? "text-brand-200" : "text-brand-600")}>{bn}</p>
        </Reveal>
      )}
      {subtitle && (
        <Reveal delay={200}>
          <p className={cn("mt-4 text-base leading-relaxed sm:text-lg", dark ? "text-white/70" : "text-ink-500")}>
            {subtitle}
          </p>
        </Reveal>
      )}
    </div>
  );
}

/* ---------- Button ---------- */
export function Button({
  children,
  variant = "primary",
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "dark" | "light" }) {
  const styles = {
    primary:
      "bg-gradient-to-b from-brand-400 to-brand-600 text-white shadow-[0_10px_30px_-8px_rgba(232,137,11,0.7),inset_0_1px_0_rgba(255,255,255,0.35)] hover:shadow-[0_16px_40px_-8px_rgba(232,137,11,0.8),inset_0_1px_0_rgba(255,255,255,0.35)]",
    ghost: "bg-white/70 text-ink-900 ring-1 ring-ink-900/10 hover:bg-white backdrop-blur",
    dark: "bg-ink-900 text-white hover:bg-ink-700 shadow-lg shadow-ink-900/20",
    light: "bg-white text-ink-900 hover:bg-cream-100 shadow-lg",
  }[variant];
  return (
    <button
      {...props}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-6 py-3.5 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-brand-200 disabled:opacity-60",
        styles,
        className
      )}
    >
      {variant === "primary" && (
        <span aria-hidden className="shimmer-btn absolute inset-0 animate-shimmer opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      )}
      <span className="relative inline-flex items-center gap-2">{children}</span>
    </button>
  );
}

/* ---------- Order context ---------- */
type OrderCtx = { open: (plan?: string) => void };
export const OrderContext = createContext<OrderCtx>({ open: () => {} });
export const useOrder = () => useContext(OrderContext);

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-7xl px-5 sm:px-8", className)}>{children}</div>;
}
