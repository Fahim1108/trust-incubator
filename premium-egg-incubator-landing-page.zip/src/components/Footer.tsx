import { MapPin, Phone, Mail } from "lucide-react";

type IconProps = { className?: string };
const Facebook = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
    <path d="M13.5 21v-7.5H16l.4-3h-2.9V8.6c0-.9.3-1.5 1.5-1.5h1.5V4.4c-.3 0-1.2-.1-2.2-.1-2.2 0-3.8 1.4-3.8 3.9v2.3H8v3h2.5V21h3Z" />
  </svg>
);
const Youtube = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
    <path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8ZM10 15V9l5.2 3L10 15Z" />
  </svg>
);
const Instagram = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <rect x="3" y="3" width="18" height="18" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.5" cy="6.5" r="0.8" fill="currentColor" />
  </svg>
);
import { Container } from "./ui";
import { Logo } from "./Navbar";

const cols = [
  { title: "Products", links: ["Trust Mini (48)", "Trust Pro (120)", "Trust Business (300)", "Spare parts", "Battery kits"] },
  { title: "Learn", links: ["Free Bangla course", "Hatching guide", "Chick buyer network", "Success stories", "Blog"] },
  { title: "Support", links: ["Track order", "Warranty claim", "Returns", "Service centers", "Contact us"] },
];

export default function Footer() {
  return (
    <footer className="relative mt-8 border-t border-ink-900/5 bg-cream-100 pt-16 pb-28 sm:pb-12">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-ink-500">
              Empowering students, housewives and young entrepreneurs across Bangladesh to build independent income —
              one egg at a time.
            </p>
            <p className="font-bn mt-2 text-sm font-medium text-brand-600">বিশ্বাসে গড়া, স্বপ্নে ফোটানো।</p>
            <ul className="mt-6 space-y-2.5 text-sm text-ink-700">
              <li className="flex items-center gap-2.5">
                <MapPin className="h-4 w-4 text-brand-500" /> House 12, Road 7, Mirpur DOHS, Dhaka 1216
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 text-brand-500" />
                <a href="tel:+8809610000000" className="hover:text-brand-600">09610-000000 (9am–10pm)</a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-brand-500" />
                <a href="mailto:hello@trustincubator.com.bd" className="hover:text-brand-600">hello@trustincubator.com.bd</a>
              </li>
            </ul>
          </div>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {cols.map((c) => (
              <nav key={c.title} aria-label={c.title}>
                <h3 className="text-sm font-bold text-ink-900">{c.title}</h3>
                <ul className="mt-4 space-y-3">
                  {c.links.map((l) => (
                    <li key={l}>
                      <a href="#top" className="text-sm text-ink-500 transition-colors hover:text-brand-600">
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-ink-900/5 pt-8 sm:flex-row">
          <p className="text-xs text-ink-500">© {new Date().getFullYear()} Trust Incubator Bangladesh. All rights reserved.</p>
          <div className="flex items-center gap-2">
            {[
              { I: Facebook, l: "Facebook" },
              { I: Youtube, l: "YouTube" },
              { I: Instagram, l: "Instagram" },
            ].map(({ I, l }) => (
              <a
                key={l}
                href="#top"
                aria-label={l}
                className="grid h-9 w-9 place-items-center rounded-full bg-white text-ink-700 ring-1 ring-ink-900/5 transition-all hover:-translate-y-0.5 hover:bg-brand-500 hover:text-white"
              >
                <I className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </Container>
    </footer>
  );
}
