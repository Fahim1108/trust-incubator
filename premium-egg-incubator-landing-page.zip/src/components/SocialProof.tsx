import { useEffect, useRef, useState } from "react";
import { Container, Reveal } from "./ui";

function CountUp({ to, suffix = "", decimals = 0 }: { to: number; suffix?: string; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return;
      io.disconnect();
      const start = performance.now();
      const dur = 1800;
      const tick = (now: number) => {
        const p = Math.min((now - start) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 4);
        setVal(to * eased);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => io.disconnect();
  }, [to]);
  return (
    <span ref={ref} className="tabular-nums">
      {val.toLocaleString("en-US", { maximumFractionDigits: decimals, minimumFractionDigits: decimals })}
      {suffix}
    </span>
  );
}

const stats = [
  { to: 12000, suffix: "+", label: "Families earning", bn: "পরিবার আয় করছে" },
  { to: 94, suffix: "%", label: "Average hatch rate", bn: "গড় হ্যাচিং রেট" },
  { to: 64, suffix: "", label: "Districts delivered", bn: "জেলায় ডেলিভারি" },
  { to: 4.9, suffix: "★", label: "Customer rating", bn: "গ্রাহক রেটিং", decimals: 1 },
];

const districts = [
  "Dhaka", "Chattogram", "Rajshahi", "Khulna", "Sylhet", "Barishal", "Rangpur", "Mymensingh",
  "Bogura", "Cumilla", "Gazipur", "Narayanganj", "Jessore", "Dinajpur", "Tangail", "Pabna",
  "Noakhali", "Feni", "Kushtia", "Faridpur", "Sirajganj", "Cox's Bazar",
];

export default function SocialProof() {
  return (
    <section aria-label="Trusted across Bangladesh" className="relative py-14 sm:py-20">
      <Container>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 90}>
              <div className="group relative h-full overflow-hidden rounded-3xl bg-white p-6 ring-1 ring-ink-900/5 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_20px_50px_-20px_rgba(158,79,10,0.35)] sm:p-8">
                <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-brand-100 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
                <p className="relative text-3xl font-extrabold tracking-tight text-ink-900 sm:text-5xl">
                  <CountUp to={s.to} suffix={s.suffix} decimals={s.decimals} />
                </p>
                <p className="relative mt-2 text-sm font-semibold text-ink-700">{s.label}</p>
                <p className="font-bn relative text-sm text-ink-500">{s.bn}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mt-14 text-center text-xs font-semibold uppercase tracking-[0.2em] text-ink-500">
            Hatching success stories from every corner of Bangladesh
          </p>
        </Reveal>
      </Container>

      <div className="relative mt-6 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
        <div className="flex w-max animate-marquee gap-3 hover:[animation-play-state:paused]">
          {[...districts, ...districts].map((d, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-2 whitespace-nowrap rounded-full bg-white/70 px-5 py-2.5 text-sm font-semibold text-ink-700 ring-1 ring-ink-900/5"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-leaf-500" />
              {d}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
