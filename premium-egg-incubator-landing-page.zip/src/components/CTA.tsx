import { ArrowRight, Phone } from "lucide-react";
import chicksImg from "@/assets/chicks-hatching.jpg";
import { Button, Container, Reveal, useOrder } from "./ui";

export default function CTA() {
  const { open } = useOrder();
  return (
    <section className="relative py-12 sm:py-20" aria-label="Order now">
      <Container>
        <Reveal>
          <div className="grain relative overflow-hidden rounded-[2.5rem] bg-ink-900 px-6 py-16 text-center text-white sm:px-12 sm:py-24">
            <img src={chicksImg} alt="" aria-hidden loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-35" />
            <div className="absolute inset-0 bg-gradient-to-br from-ink-900/95 via-ink-900/70 to-brand-700/70" />
            <div aria-hidden className="absolute -left-20 -top-20 h-72 w-72 animate-blob rounded-full bg-brand-500/40 blur-3xl" />
            <div aria-hidden className="absolute -bottom-24 -right-10 h-72 w-72 animate-blob rounded-full bg-leaf-500/30 blur-3xl [animation-delay:-7s]" />

            <div className="relative mx-auto max-w-3xl">
              <p className="font-bn text-lg font-medium text-brand-200 sm:text-xl">আজই শুরু করুন — ২১ দিন পর প্রথম আয়</p>
              <h2 className="mt-4 text-4xl font-extrabold leading-[1.05] tracking-tight text-balance sm:text-6xl">
                Your first batch of chicks is <span className="text-brand-300">21 days away.</span>
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-base text-white/70 sm:text-lg">
                Join 12,000+ Bangladeshis building independent income at home. Order today and pay only when it arrives at
                your door.
              </p>
              <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Button onClick={() => open("pro")} className="w-full px-8 py-4 text-base sm:w-auto">
                  Order Now — Cash on Delivery <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
                <a
                  href="tel:+8809610000000"
                  className="glass-dark inline-flex w-full items-center justify-center gap-2 rounded-full px-7 py-4 text-base font-semibold transition hover:bg-white/15 sm:w-auto"
                >
                  <Phone className="h-4 w-4" /> Call 09610-000000
                </a>
              </div>
              <p className="mt-6 text-xs text-white/50">✓ Free Bangla training &nbsp; ✓ 7-day return &nbsp; ✓ Warranty included</p>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
